package main;

import entidade.*;
import java.util.*;
import util.ArquivoUtil;
import util.Cadastros;

public class ProgramaPrincipal {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        List<UnidadeMedida> unidades = ArquivoUtil.carregarUnidades();
        List<Produto> produtos = ArquivoUtil.carregarProdutos();

        int opcao;
        do {
            System.out.println("\nMENU PRINCIPAL");
            System.out.println("01 - Cadastro de Unidades");
            System.out.println("02 - Cadastro de Produtos");
            System.out.println("03 - Gerar Arquivo de Carga - Unidades");
            System.out.println("04 - Gerar Arquivo de Carga - Produtos");
            System.out.println("05 - Fim");
            System.out.print("Escolha a opção: ");
            opcao = Integer.parseInt(sc.nextLine());

            switch (opcao) {
                case 1 : Cadastros.cadastroUnidade(sc, unidades);
                         break;
                case 2 : Cadastros.cadastroProduto(sc, produtos, unidades);
                         break;
                case 3 : ArquivoUtil.gerarCargaUnidades(unidades);
                         break;
                case 4 : ArquivoUtil.gerarCargaProdutos(produtos, unidades);
                         break;
                case 5 : ArquivoUtil.salvarUnidades(unidades);
                         ArquivoUtil.salvarProdutos(produtos);
                         System.out.println("Encerrando o programa.");
                         break;
                default : System.out.println("Opção inválida!");
            }
        } while (opcao != 5);
    }
}