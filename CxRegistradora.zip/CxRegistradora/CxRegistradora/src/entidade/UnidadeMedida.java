package entidade;

public class UnidadeMedida extends Entidade {
    private String codigo;
    private String nome;
    private String abreviacao;
    private boolean pesavel;

    public UnidadeMedida(String codigo, String nome, String abreviacao, boolean pesavel, boolean ativo) {
        this.codigo = codigo;
        this.nome = nome;
        this.abreviacao = abreviacao;
        this.pesavel = pesavel;
        this.ativo = ativo;
    }

    public String getCodigo() { return codigo; }
    public String getNome() { return nome; }
    public String getAbreviacao() { return abreviacao; }
    public boolean isPesavel() { return pesavel; }

    public void setNome(String nome) { this.nome = nome; }
    public void setAbreviacao(String abreviacao) { this.abreviacao = abreviacao; }
    public void setPesavel(boolean pesavel) { this.pesavel = pesavel; }
}