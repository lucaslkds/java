package entidade;

public class Produto extends Entidade {
    private String codigoProduto;
    private String nomeProduto;
    private String tipoUnidade;
    private double precoVenda;
    private double qtdDisponivel;
    private double qtdVendida;

    public Produto(String codigoProduto, String nomeProduto, String tipoUnidade,
                   double precoVenda, double qtdDisponivel, double qtdVendida, boolean ativo) {
        this.codigoProduto = codigoProduto;
        this.nomeProduto = nomeProduto;
        this.tipoUnidade = tipoUnidade;
        this.precoVenda = precoVenda;
        this.qtdDisponivel = qtdDisponivel;
        this.qtdVendida = qtdVendida;
        this.ativo = ativo;
    }

    public String getCodigoProduto() { return codigoProduto; }
    public String getNomeProduto() { return nomeProduto; }
    public String getTipoUnidade() { return tipoUnidade; }
    public double getPrecoVenda() { return precoVenda; }
    public double getQtdDisponivel() { return qtdDisponivel; }
    public double getQtdVendida() { return qtdVendida; }

    public void setNomeProduto(String nomeProduto) { this.nomeProduto = nomeProduto; }
    public void setTipoUnidade(String tipoUnidade) { this.tipoUnidade = tipoUnidade; }
    public void setPrecoVenda(double precoVenda) { this.precoVenda = precoVenda; }
    public void setQtdDisponivel(double qtdDisponivel) { this.qtdDisponivel = qtdDisponivel; }
    public void setQtdVendida(double qtdVendida) { this.qtdVendida = qtdVendida; }
}