package util;

import entidade.*;
import java.util.*;

public class Cadastros {

    public static void cadastroProduto(Scanner sc, List<Produto> produtos, List<UnidadeMedida> unidades) {
        System.out.print("Código do Produto: ");
        String codigo = sc.nextLine();

        Produto existente = produtos.stream()
            .filter(p -> p.getCodigoProduto().equals(codigo))
            .findFirst().orElse(null);

        if (existente != null) {
            System.out.print("Novo nome: "); existente.setNomeProduto(sc.nextLine());
            System.out.print("Novo tipo unidade (código): "); existente.setTipoUnidade(sc.nextLine());
            System.out.print("Novo preço de venda: "); existente.setPrecoVenda(Double.parseDouble(sc.nextLine()));
            System.out.print("Nova qtd disponível: "); existente.setQtdDisponivel(Double.parseDouble(sc.nextLine()));
            System.out.print("Nova qtd vendida: "); existente.setQtdVendida(Double.parseDouble(sc.nextLine()));
            System.out.print("Está ativo (true/false): "); existente.setAtivo(Boolean.parseBoolean(sc.nextLine()));
        } else {
            System.out.print("Nome do Produto: "); String nome = sc.nextLine();
            System.out.print("Tipo Unidade (código): "); String tipoUnidade = sc.nextLine();
            System.out.print("Preço de Venda: "); double preco = Double.parseDouble(sc.nextLine());
            System.out.print("Qtd Disponível: "); double disponivel = Double.parseDouble(sc.nextLine());
            System.out.print("Qtd Vendida: "); double vendida = Double.parseDouble(sc.nextLine());
            System.out.print("Está ativo (true/false): "); boolean ativo = Boolean.parseBoolean(sc.nextLine());

            produtos.add(new Produto(codigo, nome, tipoUnidade, preco, disponivel, vendida, ativo));
        }
    }

    public static void cadastroUnidade(Scanner sc, List<UnidadeMedida> unidades) {
        System.out.print("Código: ");
        String codigo = sc.nextLine();
        
        UnidadeMedida existente = unidades.stream()
            .filter(u -> u.getCodigo().equals(codigo))
            .findFirst().orElse(null);

        if (existente != null) {
            System.out.print("Novo nome: "); existente.setNome(sc.nextLine());
            System.out.print("Nova abreviação: "); existente.setAbreviacao(sc.nextLine());
            System.out.print("É pesável (true/false): "); existente.setPesavel(Boolean.parseBoolean(sc.nextLine()));
            System.out.print("Está ativo (true/false): "); existente.setAtivo(Boolean.parseBoolean(sc.nextLine()));
        } else {
            System.out.print("Nome: "); String nome = sc.nextLine();
            System.out.print("Abreviação: "); String abreviacao = sc.nextLine();
            System.out.print("É pesável (true/false): "); boolean pesavel = Boolean.parseBoolean(sc.nextLine());
            System.out.print("Está ativo (true/false): "); boolean ativo = Boolean.parseBoolean(sc.nextLine());
            unidades.add(new UnidadeMedida(codigo, nome, abreviacao, pesavel, ativo));
        }
    }


}