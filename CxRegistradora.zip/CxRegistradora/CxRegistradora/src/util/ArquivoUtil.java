package util;

import entidade.*;
import java.io.*;
import java.nio.file.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

public class ArquivoUtil {
    private static final String PRODUTO_CSV = "itemVenda.csv";
    private static final String UNIDADE_CSV = "tipoUnidade.csv";

    public static List<UnidadeMedida> carregarUnidades() {
        List<UnidadeMedida> unidades = new ArrayList<>();
        try (BufferedReader br = Files.newBufferedReader(Paths.get(UNIDADE_CSV))) {
            String linha;
            while ((linha = br.readLine()) != null) {
                String[] campos = linha.split(";");
                UnidadeMedida u = new UnidadeMedida(
                    campos[0], campos[1], campos[2],
                    Boolean.parseBoolean(campos[3]),
                    Boolean.parseBoolean(campos[4])
                );
                unidades.add(u);
            }
        } catch (IOException ignored) {}
        return unidades;
    }

    public static void salvarUnidades(List<UnidadeMedida> unidades) {
        try (BufferedWriter bw = Files.newBufferedWriter(Paths.get(UNIDADE_CSV))) {
            for (UnidadeMedida u : unidades) {
                bw.write(String.join(";",
                    u.getCodigo(), u.getNome(), u.getAbreviacao(),
                    String.valueOf(u.isPesavel()), String.valueOf(u.isAtivo())));
                bw.newLine();
            }
        } catch (IOException e) {
            System.err.println("Erro ao salvar unidades: " + e.getMessage());
        }
    }

    public static List<Produto> carregarProdutos() {
        List<Produto> produtos = new ArrayList<>();
        try (BufferedReader br = Files.newBufferedReader(Paths.get(PRODUTO_CSV))) {
            String linha;
            while ((linha = br.readLine()) != null) {
                String[] campos = linha.split(";");
                Produto p = new Produto(
                    campos[0], campos[1], campos[2],
                    Double.parseDouble(campos[3]),
                    Double.parseDouble(campos[4]),
                    Double.parseDouble(campos[5]),
                    Boolean.parseBoolean(campos[6])
                );
                produtos.add(p);
            }
        } catch (IOException ignored) {}
        return produtos;
    }

    public static void salvarProdutos(List<Produto> produtos) {
        try (BufferedWriter bw = Files.newBufferedWriter(Paths.get(PRODUTO_CSV))) {
            for (Produto p : produtos) {
                bw.write(String.join(";",
                    p.getCodigoProduto(), p.getNomeProduto(), p.getTipoUnidade(),
                    String.format("%.2f", p.getPrecoVenda()),
                    String.format("%.2f", p.getQtdDisponivel()),
                    String.format("%.2f", p.getQtdVendida()),
                    String.valueOf(p.isAtivo())));
                bw.newLine();
            }
        } catch (IOException e) {
            System.err.println("Erro ao salvar produtos: " + e.getMessage());
        }
    }

    public static void gerarCargaUnidades(List<UnidadeMedida> unidades) {
        String nomeArquivo = "tipoUnidade" + LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd")) + ".csv";
        try (BufferedWriter bw = Files.newBufferedWriter(Paths.get(nomeArquivo))) {
            for (UnidadeMedida u : unidades.stream().filter(UnidadeMedida::isAtivo).collect(Collectors.toList())) {
                bw.write(String.join(";",
                    u.getCodigo(), u.getNome(), u.getAbreviacao(),
                    String.valueOf(u.isPesavel()), String.valueOf(u.isAtivo())));
                bw.newLine();
            }
        } catch (IOException e) {
            System.err.println("Erro ao gerar carga de unidades: " + e.getMessage());
        }
    }

    public static void gerarCargaProdutos(List<Produto> produtos, List<UnidadeMedida> unidades) {
        Set<String> unidadesAtivas = unidades.stream()
            .filter(UnidadeMedida::isAtivo)
            .map(UnidadeMedida::getCodigo)
            .collect(Collectors.toSet());
        String nomeArquivo = "itemVenda" + LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd")) + ".csv";
        try (BufferedWriter bw = Files.newBufferedWriter(Paths.get(nomeArquivo))) {
            for (Produto p : produtos) {
                if (p.isAtivo() && unidadesAtivas.contains(p.getTipoUnidade())) {
                    bw.write(String.join(";",
                        p.getCodigoProduto(), p.getNomeProduto(), p.getTipoUnidade(),
                        String.format("%.2f", p.getPrecoVenda()),
                        String.format("%.2f", p.getQtdDisponivel()),
                        String.format("%.2f", p.getQtdVendida()),
                        String.valueOf(p.isAtivo())));
                    bw.newLine();
                }
            }
        } catch (IOException e) {
            System.err.println("Erro ao gerar carga de produtos: " + e.getMessage());
        }
    }
}
